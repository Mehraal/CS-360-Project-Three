package com.example.cs360project.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

public class DatabaseManager extends SQLiteOpenHelper {

    private static DatabaseManager instance;
    private static final String DATABASE_NAME = "data.db";
    private static final int VERSION = 2;

    public static synchronized DatabaseManager getInstance(Context context){
        if (instance == null){
            instance = new DatabaseManager(context);
        }
        return instance;
    }

    private DatabaseManager(Context context){
        super(context, DATABASE_NAME , null, VERSION);
    }

    @Override
    public void onCreate(@NonNull SQLiteDatabase db){
        db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COL_USERNAME + " TEXT, " + UserTable.COL_PASSWORD + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        onCreate(db);

    }

    public boolean authenticate(String username, String password){
        boolean isAuthenticated = false;
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            // Get a readable instance of the database.
            db = getReadableDatabase();

            // SQL query to find the user with matching username and password.
            String sql = "SELECT * FROM " + UserTable.TABLE + " WHERE " + UserTable.COL_USERNAME +
                    " = ? AND " + UserTable.COL_PASSWORD + " = ?";
            cursor = db.rawQuery(sql, new String[]{username, password});

            // Check if any results were returned.
            if (cursor.moveToFirst()) {
                isAuthenticated = true;
            }
        } finally {
            // Close the cursor and database to release resources.
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }

        return isAuthenticated;

    }



    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }
}
