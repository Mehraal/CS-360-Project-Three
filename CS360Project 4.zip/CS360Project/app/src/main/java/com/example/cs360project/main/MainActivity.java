package com.example.cs360project.main;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360project.R;
import com.example.cs360project.data.DatabaseManager;

public class MainActivity extends AppCompatActivity {

    private EditText txtUsername;
    private EditText txtPassword;
    private Button btnCreateUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(v -> handleLogin());
    }

    private void handleLogin() {
        if (txtUsername.getText().toString().equals("user") && txtPassword.getText().toString().equals("7777")) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
        } else if (txtUsername == null || txtPassword == null) {
            Toast.makeText(this, "Error: Username or Password field is missing", Toast.LENGTH_LONG).show();
            return;
        }

        String username = txtUsername.getText().toString().trim();
        String password = txtPassword.getText().toString().trim();

        if (DatabaseManager.getInstance(getApplicationContext()).authenticate(username, password)) {
            // Replace MainActivity.class with the next activity to navigate after login
            Intent intent = new Intent(this, DatabaseManager.class);
            startActivity(intent);
            finish(); // Close the current activity to prevent going back
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_LONG).show();
        }
    }
}

